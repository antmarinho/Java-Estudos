package Entities;


public class Pagamentos
{
	private Integer ID_Pag;
	private String numero;
	private Integer cvv;
	private String data_val;
	private String nome_titular;
	
	private Clientes cli;
	
	public Pagamentos()
	{
		
		
	}

	public Pagamentos(String numero, Integer cvv, String data_val, String nome_titular, Clientes cli)
	{
		this.numero = numero;
		this.cvv = cvv;
		this.data_val = data_val;
		this.nome_titular = nome_titular;
		this.cli = cli;
	}

	public Integer getID_Pag()
	{
		return ID_Pag;
	}

	public void setID_Pag(Integer ID_Pag) 
	{
		this.ID_Pag = ID_Pag;
	}

	public String getNumero()
	{
		return numero;
	}

	public void setNumero(String numero) 
	{
		this.numero = numero;
	}

	public Integer getCvv() 
	{
		return cvv;
	}

	public void setCvv(Integer cvv) 
	{
		this.cvv = cvv;
	}

	public String getData_val() 
	{
		return data_val;
	}

	public void setData_val(String data_val)
	{
		this.data_val = data_val;
	}

	public String getNome_titular()
	{
		return nome_titular;
	}

	public void setNome_titular(String nome_titular) 
	{
		this.nome_titular = nome_titular;
	}

	public Clientes getCli()
	{
		return cli;
	}

	public void setCli(Clientes cli) 
	{
		this.cli = cli;
	}

	@Override
	public String toString() 
	{
		
		return "Pagamentos [ID_Pag=" + ID_Pag + ", numero=" + numero + ", cvv=" + cvv + ", data_val=" + data_val
				+ ", nome_titular=" + nome_titular + ", cli=" + cli + "]";
	}
	
	
}
