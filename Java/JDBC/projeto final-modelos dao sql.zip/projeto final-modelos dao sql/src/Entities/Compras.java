package Entities;

import java.util.Objects;

public class Compras 
{
	private int num;
	private int qtd;
	private String date;
	private double valor;
	
	private Clientes cli;
	private Pizzas pizz;
	
	
	public Compras()
	{
		
	}


	public Compras(int num, int qtd, String date, double valor, Clientes cli, Pizzas pizz) 
	{
		this.num = num;
		this.qtd = qtd;
		this.date = date;
		this.valor = valor;
		this.cli = cli;
		this.pizz = pizz;
	}


	public int getNum() 
	{
		return num;
	}


	public void setNum(int num) 
	{
		this.num = num;
	}


	public int getQtd()
	{
		return qtd;
	}


	public void setQtd(int qtd) 
	{
		this.qtd = qtd;
	}


	public String getDate() 
	{
		return date;
	}


	public void setDate(String date) 
	{
		this.date = date;
	}


	public double getValor()
	{
		return valor;
	}


	public void setValor(double valor)
	{
		this.valor = valor;
	}


	public Clientes getCli() 
	{
		return cli;
	}


	public void setCli(Clientes cli) 
	{
		this.cli = cli;
	}


	public Pizzas getPizz()
	{
		return pizz;
	}


	public void setPizz(Pizzas pizz)
	{
		this.pizz = pizz;
	}
	
	


	@Override
	public String toString() 
	{
		return "Compras [numero pedido: " + num + ", quantidade: " + qtd + ", data pedido: " + date + ", valor: " + valor + ", cli: " + cli
				+ ", Pizza: " + pizz + "]";
	}


	@Override
	public int hashCode() 
	{
		return Objects.hash(cli, date, num, pizz, qtd, valor);
	}


	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Compras other = (Compras) obj;
		return Objects.equals(cli, other.cli) && Objects.equals(date, other.date) && num == other.num
				&& Objects.equals(pizz, other.pizz) && qtd == other.qtd
				&& Double.doubleToLongBits(valor) == Double.doubleToLongBits(other.valor);
	}
	
	

}
