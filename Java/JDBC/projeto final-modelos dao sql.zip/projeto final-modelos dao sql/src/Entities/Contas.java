package Entities;

public class Contas 
{
	private String EMAIL;
	private String senha;
	private Clientes cli;
	
	public Contas()
	{
		
	}

	public Contas(String EMAIL, String senha, Clientes cli)
	{
		this.EMAIL = EMAIL;
		this.senha = senha;
		this.cli = cli;
	}

	public String getEMAIL() 
	{
		return EMAIL;
	}

	public void setEMAIL(String EMAIL) 
	{
		this.EMAIL = EMAIL;
	}

	public String getSenha() 
	{
		return senha;
	}

	public void setSenha(String senha) 
	{
		this.senha = senha;
	}

	public Clientes getCli() 
	{
		return cli;
	}

	public void setCli(Clientes cli) 
	{
		this.cli = cli;
	}

	@Override
	public String toString() 
	{
		return "Contas [EMAIL=" + EMAIL + ", senha=" + senha + ", cli=" + cli + "]";
	}
	
	

}
