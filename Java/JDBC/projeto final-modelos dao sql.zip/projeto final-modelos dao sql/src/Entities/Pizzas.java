package Entities;

import java.util.Objects;

public class Pizzas 
{
	private Integer COD_Prod;
	private String sabor;
	private String desc;
	private Double preco;
	private String tam;
	
	
	public Pizzas()
	{
		
	}

	public Pizzas(Integer COD_Prod, String sabor, String desc, Double preco, String tam) 
	{
		this.COD_Prod = COD_Prod;
		this.sabor = sabor;
		this.desc = desc;
		this.preco = preco;
		this.tam = tam;
		
	}

	public Integer getCOD_Prod()
	{
		return COD_Prod;
	}

	public void setCOD_Prod(Integer COD_Prod) 
	{
		this.COD_Prod = COD_Prod;
	}

	public String getSabor() 
	{
		return sabor;
	}

	public void setSabor(String sabor) 
	{
		this.sabor = sabor;
	}

	public String getDesc() 
	{
		return desc;
	}

	public void setDesc(String desc)
	{
		this.desc = desc;
	}

	public Double getPreco()
	{
		return preco;
	}

	public void setPreco(Double preco)
	{
		this.preco = preco;
	}

	public String getTam()
	{
		return tam;
	}

	public void setTam(String tam) 
	{
		this.tam = tam;
	}

	@Override
	public int hashCode() 
	{
		return Objects.hash(COD_Prod, desc, preco, sabor, tam);
	}

	@Override
	public boolean equals(Object obj) 
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pizzas other = (Pizzas) obj;
		return Objects.equals(COD_Prod, other.COD_Prod) && Objects.equals(desc, other.desc)
				&& Objects.equals(preco, other.preco) && Objects.equals(sabor, other.sabor)
				&& Objects.equals(tam, other.tam);
	}

	@Override
	public String toString() 
	{
		return "Pizzas [COD_Prod: " + COD_Prod + ", sabor: " + sabor + ", descricao: " + desc + ", preco: " + preco + ", tamanho: "
				+ tam + "]";
	}
	

}
