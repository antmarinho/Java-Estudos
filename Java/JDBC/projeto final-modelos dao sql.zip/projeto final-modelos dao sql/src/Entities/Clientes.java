package Entities;

import java.util.Objects;

public class Clientes 
{
	private String CPF;
	private String firstName;
	private String lastName;
	private boolean card;
	
	public Clientes()
	{
		
	}

	public Clientes(String CPF, String name, String lname, boolean card) 
	{
		this.CPF = CPF;
		this.firstName = name;
		this.lastName = lname;
		this.card = card;
	}

	public String getCPF()
	{
		return CPF;
	}

	public void setCPF(String CPF) 
	{
		this.CPF = CPF;
	}

	public String getFirstNome()
	{
		return firstName;
	}

	public void setFirstNome(String nome) 
	{
		this.firstName = nome;
	}
	
	public String getLastNome()
	{
		return lastName;
	}

	public void setLastNome(String nome) 
	{
		this.lastName = nome;
	}

	public boolean getCard()
	{
		return card;
	}

	public void setCard(boolean card) 
	{
		this.card = card;
	}
	
	@Override
	public String toString() 
	{
		return "Clientes [CPF: " + CPF + ", Nome: " + firstName + ", Sobrenome: " + lastName + "]";
	}

	@Override
	public int hashCode() 
	{
		return Objects.hash(CPF, card, firstName, lastName);
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Clientes other = (Clientes) obj;
		return Objects.equals(CPF, other.CPF) && card == other.card && Objects.equals(firstName, other.firstName)
				&& Objects.equals(lastName, other.lastName);
	}

	


	
}
