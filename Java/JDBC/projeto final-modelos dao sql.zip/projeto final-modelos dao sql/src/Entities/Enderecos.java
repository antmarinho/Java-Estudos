package Entities;

public class Enderecos 
{
	private Integer ID_End;
	private String rua;
	private String bairro;
	private Integer numero;
	private String cidade;
	private String estado;
	private String pais;
	private String CEP;
	private String complemento;
	
	private Clientes cli;
	
	public Enderecos()
	{
		
	}

	public Enderecos(String rua, String bairro, Integer numero, String cidade, String estado, String pais, String CEP,
			String complemento, Clientes cli) 
	{
		
		this.rua = rua;
		this.bairro = bairro;
		this.numero = numero;
		this.cidade = cidade;
		this.estado = estado;
		this.pais = pais;
		this.CEP = CEP;
		this.complemento = complemento;
		this.cli = cli;
	}

	public Integer getID_End() 
	{
		return ID_End;
	}

	public void setID_End(Integer ID_End) 
	{
		this.ID_End = ID_End;
	}

	public String getRua()
	{
		return rua;
	}

	public void setRua(String rua) 
	{
		this.rua = rua;
	}

	public String getBairro() 
	{
		return bairro;
	}

	public void setBairro(String bairro) 
	{
		this.bairro = bairro;
	}

	public Integer getNumero()
	{
		return numero;
	}

	public void setNumero(Integer numero) 
	{
		this.numero = numero;
	}

	public String getCidade() 
	{
		return cidade;
	}

	public void setCidade(String cidade) 
	{
		this.cidade = cidade;
	}

	public String getEstado() 
	{
		return estado;
	}

	public void setEstado(String estado)
	{
		this.estado = estado;
	}

	public String getPais() 
	{
		return pais;
	}

	public void setPais(String pais) 
	{
		this.pais = pais;
	}

	public String getCEP()
	{
		return CEP;
	}

	public void setCEP(String CEP)
	{
		this.CEP = CEP;
	}

	public String getComplemento() 
	{
		return complemento;
	}

	public void setComplemento(String complemento) 
	{
		this.complemento = complemento;
	}

	public Clientes getCli() 
	{
		return cli;
	}

	public void setCli(Clientes cli) 
	{
		this.cli = cli;
	}

	@Override
	public String toString() 
	{
		return "Enderecos [ID_End=" + ID_End + ", rua=" + rua + ", bairro=" + bairro + ", numero=" + numero
				+ ", cidade=" + cidade + ", estado=" + estado + ", pais=" + pais + ", CEP=" + CEP + ", complemento="
				+ complemento + ", cli=" + cli + "]";
	}
	
	
}
