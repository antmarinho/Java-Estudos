package Entities;

public class Telefones 
{
	private Integer ID_Fone;
	private String fone;
	private String wapp;
	
	private Clientes cli;
	
	public Telefones()
	{
		
	}

	public Telefones(String fone, String wapp, Clientes cli)
	{
		this.fone = fone;
		this.wapp = wapp;
		this.cli = cli;
	}

	public Integer getID_Fone() 
	{
		return ID_Fone;
	}

	public void setID_Fone(Integer ID_Fone)
	{
		this.ID_Fone = ID_Fone;
	}

	public String getFone()
	{
		return fone;
	}

	public void setFone(String fone) 
	{
		this.fone = fone;
	}

	public String getWapp() 
	{
		return wapp;
	}

	public void setWapp(String wapp) 
	{
		this.wapp = wapp;
	}

	public Clientes getCli()
	{
		return cli;
	}

	public void setCli(Clientes cli) 
	{
		this.cli = cli;
	}

	@Override
	public String toString() 
	{
		return "Telefones [ID_Fone=" + ID_Fone + ", fone=" + fone + ", wapp=" + wapp + ", cli=" + cli + "]";
	}
	
	
}
