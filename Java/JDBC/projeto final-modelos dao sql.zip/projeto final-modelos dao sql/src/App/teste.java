package App;

import java.util.Scanner;
import DataBase.DBConnection;
import Entities.*;
import Model.*;
import java.util.ArrayList;
import java.util.List;

public class teste
{
	public static boolean menuOP(Clientes cli, Contas con, Enderecos end, Pagamentos pag, Telefones tel)
	{
		
		ClienteDAO cliente = Factory.createCliente();
		ContaDAO conta = Factory.createConta();
		TelefoneDAO telefone = Factory.createTelefone();
		EnderecoDAO endereco = Factory.createEndereco();
		PagamentoDAO pagamento = Factory.createPagamento();
                PizzaDAO pizza = Factory.createPizza();
                CompraDAO compra = Factory.createCompra();
		
		Scanner str = new Scanner(System.in);
		Scanner str2 = new Scanner(System.in);
		Scanner in = new Scanner(System.in);
		
		boolean check = false;
		int op;
		
		String data,fn,ln,senha,fone,wapp,ddd,rua,bairro,cidade,estado,pais,cep,complemento,numeroCar,dia,mes,ano,nome_ti;
		int numero,cvv;
		
		System.out.println("bem vindo \n" + cli.getFirstNome());
		System.out.println("email: " + con.getEMAIL());
		
		while(!check)
		{
			System.out.println("1 - editar");
			System.out.println("2 - deletar");
                        System.out.println("3 - comprar");
                        System.out.println("4 - Historico de pedidos");
			System.out.println("5 - sair");
				op = in.nextInt();
				
				switch(op)
				{
					case 1:
						
						System.out.println("1 - alterar o nome");
						System.out.println("2 - alterar a senha ");
						System.out.println("3 - alterar endereco");
						System.out.println("4 - alterar telefone");
						System.out.println("5 - alterar cartao");
							op = str.nextInt();
							
						if(op == 1)
						{
							System.out.println("digite o novo nome");
								fn = str2.nextLine();
								
							System.out.println("digite o novo sobrenome");
								ln = str2.nextLine();	
							
							if(!fn.equalsIgnoreCase(""))
								cli.setFirstNome(fn);
							if(!ln.equalsIgnoreCase(""))
								cli.setLastNome(ln);
							
							cliente.update(cli);
							
						}
						
						if(op == 2)
						{
							System.out.println("digite a nova senha");
								senha = str2.nextLine();
								
							if(!senha.equalsIgnoreCase(""))
								con.setSenha(senha);
							
							conta.update(con);
							
						}
						
						if(op == 3)
						{
							System.out.println("a nova rua");
								rua = str2.nextLine();
						
							System.out.println("o novo bairro");
								bairro = str2.nextLine();
								
							System.out.println("o novo numero");
								numero = in.nextInt();
								
							System.out.println("a nova cidade");
								cidade = str2.nextLine();
								
							System.out.println("o novo estado");
								estado = str2.nextLine();
								
							System.out.println("o novo pais");
								pais = str2.nextLine();
							
							System.out.println("o nvo cep");
								cep = str2.nextLine();
							
							System.out.println("o novo complemento");
								complemento = str2.nextLine();
								
							if(!bairro.equalsIgnoreCase(""))	
								end.setBairro(bairro);
							if(!rua.equalsIgnoreCase(""))
								end.setRua(rua);
							if(numero > 0)
								end.setNumero(numero);
							if(!cidade.equalsIgnoreCase(""))
								end.setCidade(cidade);
							if(!estado.equalsIgnoreCase(""))
								end.setEstado(estado);
							if(!pais.equalsIgnoreCase(""))
								end.setPais(pais);
							if(!cep.equalsIgnoreCase(""))
							{
								cep = Functions.Functions.formataCEP(cep);
								end.setCEP(cep);
							}
							if(!complemento.equalsIgnoreCase(""))
								end.setComplemento(complemento);
							
							endereco.update(end);
						}
						
						if(op == 4)
						{
							System.out.println("DDD");
								ddd = str2.nextLine();

							System.out.println("digite o novo telefone");
								fone = str2.nextLine();
						
							System.out.println("DDD");
								ddd = str2.nextLine();

							System.out.println("digite o novo whatsapp");
								wapp = str2.nextLine();
							
							
							if(!fone.equalsIgnoreCase(""))
							{	
								fone = Functions.Functions.formataTel(ddd,fone);
								tel.setFone(fone);
							}
							if(!wapp.equalsIgnoreCase(""))
							{
								wapp = Functions.Functions.formataTel(ddd,wapp);
								tel.setWapp(wapp);
							}
							
							telefone.update(tel);
							
						}
						
						if(op == 5)
						{
							if(!cli.getCard())
							{
								System.out.println("vc n tem cartao cadastrado");
								System.out.println("1 - para add");
								System.out.println("2 - para sair");
									op = in.nextInt();
								
								if(op == 1)
								{	
									pag = new Pagamentos();
									
									System.out.println("Numero cartao");
										numeroCar = str2.nextLine();
									
									numeroCar = Functions.Functions.formataCartao(numeroCar);
									
									System.out.println("cvv");
										cvv = in.nextInt();
									
									System.out.println("dia");
										dia = str2.nextLine();
										
									System.out.println("mes");
										mes = str2.nextLine();
										
									System.out.println("ano");
										ano = str2.nextLine();
										
									System.out.println("nome titular");
										nome_ti = str2.nextLine();
												
									data = Functions.Functions.formataData(dia, mes, ano);
									
									pag.setNumero(numeroCar);
									pag.setCvv(cvv);
									pag.setData_val(data);
									pag.setNome_titular(nome_ti);
									pag.setCli(cli);
									
									if(pagamento.insert(pag));
									{
										cli.setCard(true);
										cliente.updateCard(cli);
									}
	
									
								}
								
								
							}
							
							else
							{
								System.out.println("o novo Numero cartao");
									numeroCar = str2.nextLine();
								
								System.out.println("o novo cvv");
									cvv = in.nextInt();
								
								System.out.println("o novio dia");
									dia = str2.nextLine();
									
								System.out.println("o novo mes");
									mes = str2.nextLine();
									
								System.out.println("o novo ano");
									ano = str2.nextLine();
									
								System.out.println("o novo nome titular");
									nome_ti = str2.nextLine();
											
								
								if(!numeroCar.equalsIgnoreCase(""))
								{
									numeroCar = Functions.Functions.formataCartao(numeroCar);
									pag.setNumero(numeroCar);
								}
								
								if(cvv > 0)
									pag.setCvv(cvv);
								
								if(!nome_ti.equalsIgnoreCase(""))
									pag.setNome_titular(nome_ti);
								
				
								data = Functions.Functions.formataData(dia, mes, ano);
								pag.setData_val(data);

								
								pagamento.update(pag);
								
							}
							
						}
			
						
					break;
					
					case 2:
						
						System.out.println("1 - deletar cartao");
						System.out.println("2 - deleta a conta");
							op = str.nextInt();
							
						if(op == 1)
						{
							if(!cli.getCard())
								System.out.println("vc n tem cartao cadastrado");
							else
							{
								pagamento.delete(cli.getCPF());
								
								cli.setCard(false);
								cliente.updateCard(cli);
								
								System.out.println("cartao deletado");
							}
							
						}
						
						if(op == 2)
						{
							cliente.delete(cli.getCPF());
							
							System.out.println("conta deletada");
							
							check = true;
                                                        
                                                        return true;
						}
						
					break;
                                        
                                        case 3:
                                            
                                            if(!cli.getCard())
                                            {
						System.out.println("vc n tem cartao cadastrado");
                                                System.out.println("Adicionar cartao");
                                                
                                                pag = new Pagamentos();
									
						System.out.println("Numero cartao");
                                                    numeroCar = str2.nextLine();
									
                                                    numeroCar = Functions.Functions.formataCartao(numeroCar);
									
						System.out.println("cvv");
                                                    cvv = in.nextInt();
									
						System.out.println("dia");
                                                    dia = str2.nextLine();
										
						System.out.println("mes");
                                                    mes = str2.nextLine();
										
						System.out.println("ano");
                                                    ano = str2.nextLine();
										
						System.out.println("nome titular");
                                                    nome_ti = str2.nextLine();
												
						data = Functions.Functions.formataData(dia, mes, ano);
									
						pag.setNumero(numeroCar);
						pag.setCvv(cvv);
						pag.setData_val(data);
						pag.setNome_titular(nome_ti);
                                                pag.setCli(cli);
									
                                                if(pagamento.insert(pag));
						{
                                                    cli.setCard(true);
                                                    cliente.updateCard(cli);
						}
                                              
                                            }
                                            else
                                            {
                                                
                                                check = false;
                                            
                                                while (!check)    
                                                {    
                                                    int verif = 0;
                                                    int quant,j = 0;

                                                    Compras[] comp = new Compras[12];

                                                    for(int i = 0; i < comp.length; i++)
                                                        comp[i] = new Compras();

                                                    List<Pizzas> pi = new ArrayList<Pizzas>();
                                                    List<Compras> carrinho = new ArrayList<Compras>();

                                                    pi = pizza.findAll();

                                                    while(verif != 2 && j < 12)
                                                    {
                                                        for(int i = 0; i < pi.size(); i++)
                                                        {
                                                            System.out.println("[" + (i + 1)+ "] - para comprar a pizza " + pi.get(i).getSabor());
                                                        }

                                                        op = in.nextInt();

                                                        op = (op - 1);


                                                        comp[j].setCli(cli);
                                                        comp[j].setPizz(pi.get(op));

                                                        System.out.println("Quantas pizzas dessa deseja comprar");
                                                            quant = in.nextInt();

                                                        comp[j].setQtd(quant);
                                                        comp[j].setValor((pi.get(op).getPreco() * quant));

                                                        carrinho.add(comp[j]);

                                                        System.out.println("para continuar comprado digite [1]");
                                                        System.out.println("sair [2]");
                                                            verif = in.nextInt();

                                                        if(verif == 1)
                                                            j++;

                                                    }

                                                    System.out.println("Finalizar pedido digite [1]");
                                                    System.out.println("Modificar pedido [2]");
                                                        op = in.nextInt();

                                                    if(op == 1)
                                                    {
                                                        compra.inset(carrinho);
                                                        check = true;
                                                    }

                                                    
                                                }
                                                
                                            }
                                            
                                        break;
                                        
                                        case 4:
                                            
                                            List<Compras> comprl = new ArrayList<Compras>();
                                            
                                            comprl = compra.findAll();
                                            
                                            if(!comprl.isEmpty())
                                            {
                                            
                                                for(int i = 0; i < comprl.size(); i++)
                                                    System.out.println(comprl.get(i));
                                            }
                                            
                                            else
                                                System.out.println("vc n comproun nada");
                                            
                                        break;
					
					case 5:
						
						check = true;
						
					break;
					
					default:
						
						System.out.println("Opcao invalida");
						
					break;
				}
				
				
		}
		
		DBConnection.getConnection();
                
                return false;
		
	}
	
	public static void menu()
	{
		boolean check = false;
		int op;
		
		Scanner str = new Scanner(System.in);
		Scanner in = new Scanner(System.in);
		
		ClienteDAO cliente = Factory.createCliente();
		ContaDAO conta = Factory.createConta();
		TelefoneDAO telefone = Factory.createTelefone();
		EnderecoDAO endereco = Factory.createEndereco();
		PagamentoDAO pagamento = Factory.createPagamento();

		
		while(!check)
		{
			
			System.out.println("1 - login");
			System.out.println("2 - cadastro");
			System.out.println("3 - sair");
				op = in.nextInt();
				
			switch(op)
			{
				case 1:
					
					String email1,senha1;
					
					System.out.println("email");
						email1 = str.nextLine();
						
					
					Contas cont1 = conta.findEmail(email1);
					
					
						if(cont1 == null)
							System.out.println("email n cadastrado");
						
						else
						{
							System.out.println("senha");
								senha1 = str.nextLine();
							
							if (!cont1.getSenha().equalsIgnoreCase(senha1))
								System.out.println("senha errada");
							
							else
							{
								
								Clientes cli1 = cliente.find(cont1.getCli().getCPF());
								Telefones tel1 = telefone.find(cli1.getCPF());
								Enderecos end1 = endereco.find(cli1.getCPF());
								Pagamentos pag1 = pagamento.find(cli1.getCPF());
								
								check = menuOP(cli1, cont1, end1, pag1, tel1);
								
							}
							
						}
						
					
				break;
				
				case 2:
					
					String data,cpf,fn,ln,email,senha,fone,wapp,ddd,rua,bairro,cidade,estado,pais,cep,complemento,numeroCar,dia,mes,ano,nome_ti;
					int numero,cvv;
					boolean vCpf,card = false;
					
					//ClienteDAO cliente = Factory.createCliente();
					
					Clientes cli = new Clientes();
					
					System.out.println("cpf");
						cpf = str.nextLine();
						
						if(cliente.find(cpf) == null)
						{	
						
							vCpf = Functions.Functions.verifCPF(Functions.Functions.convertString(cpf));
							
							if(!vCpf)
								System.out.println("cpf invalido");
							else
							{
								System.out.println("email");
								email = str.nextLine();
								
								//ContaDAO conta = Factory.createConta();
								
								if(conta.findEmail(email) == null)
								{
								
									cpf = Functions.Functions.formataCPF(cpf);
									
									System.out.println("nome");
									fn = str.nextLine();
									
									System.out.println("sobrenome");
									ln = str.nextLine();
									
									cli.setCard(card);
									cli.setCPF(cpf);
									cli.setFirstNome(fn);
									cli.setLastNome(ln);
									
									cliente.insert(cli);
									
									System.out.println("senha");
										senha = str.nextLine();
										
									Contas cont = new Contas();
										
									cont.setEMAIL(email);
									cont.setSenha(senha);
									cont.setCli(cli);
									
									conta.insert(cont);
									
									System.out.println("DDD");
										ddd = str.nextLine();

									System.out.println("telefone");
										fone = str.nextLine();
										
									fone = Functions.Functions.formataTel(ddd,fone);
									
									System.out.println("DDD");
										ddd = str.nextLine();

									System.out.println("whatsapp");
										wapp = str.nextLine();
										
									wapp = Functions.Functions.formataTel(ddd,wapp);
									
									Telefones tel = new Telefones();
									
									tel.setFone(fone);
									tel.setWapp(wapp);
									tel.setCli(cli);
									
									//TelefoneDAO telefone = Factory.createTelefone();
									
									telefone.insert(tel);
									
									System.out.println("rua");
										rua = str.nextLine();
									
									System.out.println("bairro");
										bairro = str.nextLine();
										
									System.out.println("numero");
										numero = in.nextInt();
										
									System.out.println("cidade");
										cidade = str.nextLine();
										
									System.out.println("estado");
										estado = str.nextLine();
										
									System.out.println("pais");
										pais = str.nextLine();
									
									System.out.println("cep");
										cep = str.nextLine();
										
									cep = Functions.Functions.formataCEP(cep);
										
									System.out.println("complemento");
										complemento = str.nextLine();
										
									Enderecos end = new Enderecos();
									
									end.setBairro(bairro);
									end.setRua(rua);
									end.setNumero(numero);
									end.setCidade(cidade);
									end.setEstado(estado);
									end.setPais(pais);
									end.setCEP(cep);
									end.setComplemento(complemento);
									end.setCli(cli);
										
									//EnderecoDAO endereco = Factory.createEndereco();
									
									endereco.insert(end);
									
									System.out.println("Numero cartao");
										numeroCar = str.nextLine();
										
									numeroCar = Functions.Functions.formataCartao(numeroCar);
									
									System.out.println("cvv");
										cvv = in.nextInt();
									
									System.out.println("dia");
										dia = str.nextLine();
										
									System.out.println("mes");
										mes = str.nextLine();
										
									System.out.println("ano");
										ano = str.nextLine();
										
									System.out.println("nome titular");
										nome_ti = str.nextLine();
												
									data = Functions.Functions.formataData(dia, mes, ano);
									
									Pagamentos pag = new Pagamentos();
									
									pag.setNumero(numeroCar);
									pag.setCvv(cvv);
									pag.setData_val(data);
									pag.setNome_titular(nome_ti);
									pag.setCli(cli);
									
									//PagamentoDAO pagamento = Factory.createPagamento();
									
									if(pagamento.insert(pag));
									{
										cli.setCard(true);
										cliente.updateCard(cli);
										
									}
									
								}
								
								else
									System.out.println("email ja cadastrado");
								
							}
							
						}
						
						else
							System.out.println("cpf ja cadastrado");
						
					
				break;
				
				case 3:
					
					check = true;
					
				break;
				
				default:
					
					System.out.println("Opcao invalida");
					
				break;
				
			}
			
			
		}
		
		DBConnection.getConnection();
		
	}

	public static void main(String[] args) {

		menu();
                
               /*CompraDAO comp = Factory.createCompra();
                List<Compras> compra = new ArrayList<Compras>();
                
                Clientes cli = new Clientes("093.427.514-90","","", true);
                Pizzas pizz = new Pizzas(4444,"Marguerita","",30.0,"G");
                
                Compras com = new Compras();
                
                com.setQtd(3);
                com.setValor(90);
                com.setCli(cli);
                com.setPizz(pizz);
                        
                compra.add(com);
                
                Compras com1 = new Compras();
                
                Clientes cli1 = new Clientes("093.427.514-90","","", true);
                Pizzas pizz1 = new Pizzas(5555,"Quatro queijos","",40.0,"G");
                
                com1.setQtd(2);
                com1.setValor(120);
                com1.setCli(cli1);
                com1.setPizz(pizz1);
                
                compra.add(com1);
                
                comp.inset(compra);
                
                /*
                compra = comp.findAll();
                
                for(int i = 0; i < compra.size(); i++)
                {
                    System.out.println(compra.get(i));
                    
                }*/
               
               
                
                
                //PizzaDAO pizza = Factory.createPizza();
                
               // List<Pizzas> pizz = new ArrayList<Pizzas>();
               // Pizzas piz = new Pizzas();
                
               // System.out.println(piz = pizza.find(1200));
                
               // pizz = pizza.findAll();
                
               // for(int i = 0; i < pizz.size(); i++)
              //  {
               //     System.out.println(pizz.get(i));
                    
               //}
                
                    

		// Clientes cli = new Clientes();

		// cli.setCPF("11111111111");
		// cli.setFirstNome("jose");
		// cli.setLastNome("silva");
		// cli.setCard(false);

		// Contas cont = new Contas("jose@gmail.com","12345",cli);
		// Telefones tel = new Telefones("12345678","22222222",cli);
		// Pagamentos pag = new Pagamentos("11111",123,"2010-10-10","Jose", cli);
		// Enderecos end = new Enderecos("uhdrur", "whdewuhe", 3, "dfdef", "rfrfg",
		// "efd", "fdfd", "dfdf", cli);

		// cliente.insert(cli);
		// conta.insert(cont);
		// telefone.insert(tel);
		// pagamento.insert(pag);
		// cli.setCard(true);
		// cliente.updateCard(cli);
		// endereco.insert(end);

		// cliente.delete(cli.getCPF());
		// pagamento.delete(cli.getCPF());
		// cli.setCard(false);
		// cliente.updateCard(cli);

		// cli.setFirstNome("Ricardo");
		// cliente.update(cli);
		// cont.setSenha("123456789");
		// conta.update(cont);
		// end.setCEP("51350-610");
		// end.setNumero(205);
		// end.setRua("avenida presidente kennedy");
		// endereco.update(end);
		// pag.setCvv(2468);
		// pag.setData_val("2030-2-5");
		// pagamento.update(pag);
		// tel.setFone("000000000");
		// tel.setWapp(null);
		// telefone.update(tel);

		// System.out.println(cliente.find("11111111111"));
		// System.out.println(conta.find("11111111111"));
		// System.out.println(endereco.find("11111111111"));
		// System.out.println(telefone.find("11111111111"));
		// System.out.println(pagamento.find("11111111111"));

		// cliente.delete("11111111111");

		 //DBConnection.getConnection();

	}
}
