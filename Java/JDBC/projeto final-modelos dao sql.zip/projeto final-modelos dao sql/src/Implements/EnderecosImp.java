package Implements;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.cj.jdbc.StatementImpl;

import Entities.Clientes;
import Entities.Enderecos;
import Model.ClienteDAO;
import Model.EnderecoDAO;
import Model.Factory;


public class EnderecosImp implements EnderecoDAO
{

	private Connection connection;
	
	public EnderecosImp(Connection connection)
	{
		this.connection = connection;
	}
	
	@Override
	public void insert(Enderecos end) 
	{
		PreparedStatement stmt = null;
		
		String insert = "INSERT INTO enderecos (rua,bairro,numero,cidade,estado,pais,CEP,complemento,CPF_cliente)" + " VALUES(?,?,?,?,?,?,?,?,?)";
		
		try 
		{
			int check = 0;
			int id;
			
			stmt = connection.prepareStatement(insert, StatementImpl.RETURN_GENERATED_KEYS);
			
			stmt.setString(1,end.getRua());
			stmt.setString(2,end.getBairro());
			stmt.setInt(3,end.getNumero());
			stmt.setString(4,end.getCidade());
			stmt.setString(5,end.getEstado());
			stmt.setString(6,end.getPais());
			stmt.setString(7,end.getCEP());
			stmt.setString(8,end.getComplemento());
			stmt.setString(9,end.getCli().getCPF());
			check = stmt.executeUpdate();
			
			if(check > 0)
			{
				ResultSet rs = stmt.getGeneratedKeys();
				
				if(rs.next())
				{
					id = rs.getInt(1);
					end.setID_End(id);
					
					System.out.println("INSERT CONCLUIDO");
				}
				
			}
			
			stmt.close();
		} 
		
		catch (SQLException err) 
		{
                    throw new RuntimeException("ERRO AO INSERIR");
		}
		
	}

	/*@Override
	public void delete(String CPF) 
	{
		PreparedStatement stmt = null;
		
		String delete = "DELETE FROM enderecos WHERE CPF_cliente = ?";
		
		int check = 0;
		
		try 
		{
			stmt = connection.prepareStatement(delete);
			stmt.setString(1,CPF);
			check = stmt.executeUpdate();
			
			if(check > 0)
				System.out.println("DELETE CONCLUIDO");
			
			stmt.close();
			
		} 
		
		catch (SQLException err) 
		{
			throw new RuntimeException("ERRO AO DELETAR");
		}
		
	}*/

	@Override
	public void update(Enderecos end) 
	{
		PreparedStatement stmt = null;
		
		String update = "UPDATE enderecos SET rua = ?, bairro = ?, numero = ?, cidade = ?, estado = ?, pais = ?, CEP = ?, complemento = ?" + " WHERE CPF_cliente = ?";
		
		try 
		{
			int check;
			
			stmt = connection.prepareStatement(update);
			stmt.setString(1,end.getRua());
			stmt.setString(2,end.getBairro());
			stmt.setInt(3,end.getNumero());
			stmt.setString(4,end.getCidade());
			stmt.setString(5,end.getEstado());
			stmt.setString(6,end.getPais());
			stmt.setString(7,end.getCEP());
			stmt.setString(8,end.getComplemento());
			stmt.setString(9,end.getCli().getCPF());
			check = stmt.executeUpdate();
			
			if(check > 0)
				System.out.println("UPDATE CONCLUIDO");
			
			stmt.close();
			
		} 
		
		catch (SQLException err) 
		{
			throw new RuntimeException("ERRO AO ATUALIZAR");
		}
		
	}

	@Override
	public Enderecos find(String cpf) 
	{
		String select = "SELECT * FROM enderecos WHERE CPF_cliente = ?";
		
		PreparedStatement stmt = null;
		ResultSet rs;
		
		try 
		{
			stmt = connection.prepareStatement(select);
			stmt.setString(1,cpf);
			
			rs = stmt.executeQuery();
			
			if (rs.next())
			{
				Enderecos end = new Enderecos();
				
				ClienteDAO cliente = Factory.createCliente();
				
				Clientes cli = cliente.find(cpf);
				
				end.setID_End(rs.getInt("ID_End"));
				end.setRua(rs.getString("rua"));
				end.setBairro(rs.getNString("bairro"));
				end.setNumero(rs.getInt("numero"));
				end.setCidade(rs.getString("cidade"));
				end.setEstado(rs.getString("estado"));
				end.setPais(rs.getString("pais"));
				end.setCEP(rs.getString("CEP"));
				end.setComplemento(rs.getNString("complemento"));
				end.setCli(cli);
				
				stmt.close();
				//connection.close();
				
				return end;
				
			}
			
			return null;
			
		} 
		
		catch (SQLException err) 
		{
			
			throw new RuntimeException("ERRO AO PESQUISAR");
		}
	
				
	}
	
}
