package Implements;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.cj.jdbc.StatementImpl;
import Entities.Clientes;
import Entities.Pagamentos;
import Model.ClienteDAO;
import Model.Factory;
import Model.PagamentoDAO;


public class PagamentosImp implements PagamentoDAO
{
	private Connection connection;
	
	
	public PagamentosImp(Connection connection)
	{
		this.connection = connection;
	}

	@Override
	public boolean insert(Pagamentos pag)
	{
		PreparedStatement stmt = null;
		
		String insert = "INSERT INTO pagamentos (numero,cvv,data_val,nome_titular,CPF_cliente)" + " VALUES (?,?,?,?,?)";
		
		try 
		{
			int check = 0;
			int id;
			
			stmt = connection.prepareStatement(insert,StatementImpl.RETURN_GENERATED_KEYS);
			
			stmt.setString(1,pag.getNumero());
			stmt.setInt(2,pag.getCvv());
			stmt.setString(3,pag.getData_val());
			stmt.setString(4,pag.getNome_titular());
			stmt.setString(5,pag.getCli().getCPF());
			check = stmt.executeUpdate();
			
			if(check > 0)
			{
				ResultSet rs = stmt.getGeneratedKeys();
				
				if(rs.next())
				{
					id = rs.getInt(1);
					pag.setID_Pag(id);
					
					System.out.println("INSERT CONCLUIDO");
					
					return true;
				}
				
			}
			
			stmt.close();
			
		} 
		
		catch (SQLException err) 
		{
			throw new RuntimeException("ERRO AO INSERIR");
		}
		
		return false;
		
	}

	@Override
	public void delete(String CPF) 
	{
		PreparedStatement stmt = null;
		
		String delete = "DELETE FROM pagamentos WHERE CPF_cliente = ?";
		
		int check = 0;
		
		try 
		{
			stmt = connection.prepareStatement(delete);
			
			stmt.setString(1,CPF);
			check = stmt.executeUpdate();
			
			if(check > 0)
				System.out.println("DELETE CONCLUIDO");
			
			stmt.close();
		} 
		
		catch (SQLException err) 
		{
			throw new RuntimeException("ERRO AO DELETAR");
		}
		
	}

	@Override
	public void update(Pagamentos pag) 
	{
		PreparedStatement stmt = null;
		
		String update = "UPDATE pagamentos SET numero = ?, cvv = ?, data_val = ?, nome_titular = ?" + " WHERE CPF_cliente = ?";
		
		try 
		{
			int check;
			
			stmt = connection.prepareStatement(update);
			stmt.setString(1,pag.getNumero());
			stmt.setInt(2,pag.getCvv());
			stmt.setString(3,pag.getData_val());
			stmt.setString(4,pag.getNome_titular());
			stmt.setString(5,pag.getCli().getCPF());
			check = stmt.executeUpdate();
			
			if(check > 0)
				System.out.println("UPDATE CONCLUIDO");
			
			stmt.close();
			
		} 
		
		catch (SQLException err) 
		{
			throw new RuntimeException("ERRO AO ATUALIZAR");
		}
		
	}

	@Override
	public Pagamentos find(String cpf) 
	{
		String select = "SELECT * FROM pagamentos WHERE CPF_cliente = ?";
		
		PreparedStatement stmt = null;
		ResultSet rs;
		
		try 
		{
			stmt = connection.prepareStatement(select);
			stmt.setString(1,cpf);
			
			rs = stmt.executeQuery();
			
			if (rs.next())
			{
				Pagamentos pag = new Pagamentos();
				
				ClienteDAO cliente = Factory.createCliente();
				
				Clientes cli = cliente.find(cpf);
				
				pag.setID_Pag(rs.getInt("ID_Pag"));
				pag.setNumero(rs.getString("numero"));
				pag.setCvv(rs.getInt("cvv"));
				pag.setData_val(Functions.Functions.formataDataBrasil(rs.getString("data_val")));
				pag.setNome_titular(rs.getNString("nome_titular"));
				pag.setCli(cli);
				
				stmt.close();
				//connection.close();
				
				return pag;
				
			}
			
			return null;
			
		} 
		
		catch (SQLException err) 
		{
			
			throw new RuntimeException("ERRO AO PESQUISAR");
		}
		

	}
	
}
