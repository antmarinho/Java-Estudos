package Implements;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Entities.Clientes;
import Entities.Contas;
import Model.ClienteDAO;
import Model.ContaDAO;
import Model.Factory;

public class ContasImp implements ContaDAO
{

	private Connection connection;
	
	
	public ContasImp(Connection conecction)
	{
		this.connection = conecction;
	}
	
	@Override
	public void insert(Contas conta)
	{
		PreparedStatement stmt = null;
		
		String insert = "INSERT INTO contas (EMAIL,senha,CPF_cliente)" + " VALUES(?,?,?)";
		
		try 
		{
			int check = 0;
			
			stmt = connection.prepareStatement(insert);
			stmt.setString(1,conta.getEMAIL());
			stmt.setString(2,conta.getSenha());
			stmt.setString(3,conta.getCli().getCPF());
			check = stmt.executeUpdate();
			
			if(check > 0)
				System.out.println("INSERT CONCLUIDO");
			
			stmt.close();
			
		} 
		
		catch (SQLException e)
		{
			throw new RuntimeException("ERRO AO INSERIR");
		}
		
	}

	@Override
	public void update(Contas conta) 
	{
		PreparedStatement stmt = null;
		
		String update = "UPDATE contas SET senha = ?" + " WHERE CPF_cliente = ?";
		
		try 
		{
			int check;
			
			stmt = connection.prepareStatement(update);
			stmt.setString(1,conta.getSenha());
			stmt.setString(2,conta.getCli().getCPF());
			check = stmt.executeUpdate();
			
			if(check > 0)
				System.out.println("UPDATE CONCLUIDO");
			
			stmt.close();
			
		} 
		
		catch (SQLException err) 
		{
			throw new RuntimeException("ERRO AO ATUALIZAR");
		}
		
	}

	@Override
	public Contas find(String cpf)
	{
		
		String select = "SELECT * FROM contas WHERE CPF_cliente = ?";
		
		PreparedStatement stmt = null;
		ResultSet rs;
		
		try 
		{
			stmt = connection.prepareStatement(select);
			stmt.setString(1,cpf);
			
			rs = stmt.executeQuery();
			
			if (rs.next())
			{
				Contas cont = new Contas();
				
				ClienteDAO cliente = Factory.createCliente();
				
				Clientes cli = cliente.find(cpf);
				
				cont.setEMAIL(rs.getNString("EMAIL"));
				cont.setSenha(rs.getNString("senha"));
				cont.setCli(cli);
				
				stmt.close();
				//connection.close();
				
				return cont;
			}
			
			return null;
			
		} 
		
		catch (SQLException err) 
		{
			
			throw new RuntimeException("ERRO AO PESQUISAR");
		}
		
	}

	@Override
	public Contas findEmail(String EMAIL) 
	{
		String select = "SELECT * FROM contas WHERE EMAIL = ?";
		
		PreparedStatement stmt = null;
		ResultSet rs;
		
		try 
		{
			stmt = connection.prepareStatement(select);
			stmt.setString(1,EMAIL);
			
			rs = stmt.executeQuery();
			
			Contas cont = new Contas();
			
			if (rs.next())
			{
				
				ClienteDAO cliente = Factory.createCliente();
				
				Clientes cli = cliente.findEmail(EMAIL);
				
				cont.setEMAIL(rs.getNString("EMAIL"));
				cont.setSenha(rs.getNString("senha"));
				cont.setCli(cli);
				
				stmt.close();
				
				return cont;
			}
			
			return null;
			
		} 
		
		catch (SQLException err) 
		{
			
			throw new RuntimeException("ERRO AO PESQUISAR");
		}
		
	}
	
}
