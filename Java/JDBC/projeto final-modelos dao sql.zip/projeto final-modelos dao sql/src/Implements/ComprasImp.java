package Implements;

import Entities.Clientes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Entities.Compras;
import Entities.Pizzas;
import Model.ClienteDAO;
import Model.CompraDAO;
import Model.Factory;
import Model.PizzaDAO;
import com.mysql.cj.jdbc.StatementImpl;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ComprasImp implements CompraDAO
{

	private Connection connection;
	
	public ComprasImp(Connection connection)
	{
		this.connection = connection;
	}
	
	@Override
	public void inset(List<Compras> pizz) 
	{
            PreparedStatement stmt = null;
            
            String insert = "INSERT INTO compras (CPF_cliente,COD_prod,qtd,valor)" + " VALUES(?,?,?,?)";
			
            try 
            {
                int check = 0;
                int id;
            
                for(int i = 0; i < pizz.size(); i++)
                {
                
                    stmt = connection.prepareStatement(insert, StatementImpl.RETURN_GENERATED_KEYS);
                
                    stmt.setString(1,pizz.get(i).getCli().getCPF());
                    stmt.setInt(2,pizz.get(i).getPizz().getCOD_Prod());
                    stmt.setInt(3,pizz.get(i).getQtd());
                    stmt.setDouble(4,pizz.get(i).getValor());
                    check = stmt.executeUpdate();
                    
                    if(check > 0)
                    {
			ResultSet rs = stmt.getGeneratedKeys();
				
			if(rs.next())
			{
                            id = rs.getInt(1);
                            pizz.get(i).setNum(id);
					
                            System.out.println("INSERT CONCLUIDO");
			}
				
                    }
                    
                }
                
                stmt.close();
            
            } 
            
            catch (SQLException ex) 
            {
                throw new RuntimeException("ERRO AO INSERIR");
            }
		
	}

	@Override
	public List<Compras> findAll()
	{
		
		List<Compras> listaComp = new ArrayList<>();
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		String selec = "SELECT * FROM compras C INNER JOIN clientes D ON C.CPF_cliente = D.CPF INNER JOIN pizzas P ON C.COD_prod = P.COD_Prod";
		
		try 
		{
			stmt = connection.prepareStatement(selec);
			
			rs = stmt.executeQuery();
			
			while(rs.next())
			{
				Compras comp = new Compras();
				
				ClienteDAO cli = Factory.createCliente();
                                PizzaDAO piz = Factory.createPizza();
                                
                                Clientes cliente = cli.find(rs.getNString("CPF_cliente"));
                                Pizzas pizza = piz.find(rs.getInt("COD_prod"));
				
                                comp.setNum(rs.getInt("NUM"));
                                comp.setDate(rs.getString("data_pedido"));
                                comp.setQtd(rs.getInt("qtd"));
                                comp.setValor(rs.getDouble("valor"));
                                comp.setCli(cliente);
                                comp.setPizz(pizza);
				
				listaComp.add(comp);
				
			}
			
			stmt.close();
		} 
		
		catch (SQLException err) 
		{
		err.printStackTrace();	//throw new RuntimeException("ERRO AO PESQUISAR");
		}
		
		return listaComp;
                
	}
       
}
