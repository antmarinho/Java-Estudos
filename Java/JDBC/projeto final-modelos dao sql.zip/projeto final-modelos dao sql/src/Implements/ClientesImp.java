package Implements;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Entities.Clientes;
import Model.ClienteDAO;

public class ClientesImp implements ClienteDAO
{

	private Connection connection;
	
	
	public ClientesImp(Connection connnection)
	{
		this.connection = connnection;
	}
	
	@Override
	public void insert(Clientes cliente) 
	{
		PreparedStatement stmt = null;
		
		String insert = "INSERT INTO clientes (CPF,firstName,lastName,card)" + " VALUES(?,?,?,?)";
		
		try 
		{
			int check = 0;
		
			stmt = connection.prepareStatement(insert);
			stmt.setString(1,cliente.getCPF());
			stmt.setString(2,cliente.getFirstNome());
			stmt.setString(3,cliente.getLastNome());
			stmt.setBoolean(4,cliente.getCard());
			check = stmt.executeUpdate();
			
			if(check > 0)
				System.out.println("INSERT CONCLUIDO");
			
			stmt.close();
			
		} 
		
		catch (SQLException err) 
		{
			throw new RuntimeException("ERRO AO INSERIR");
		}
		
	}

	@Override
	public void delete(String CPF) 
	{
		PreparedStatement stmt = null;
		
		String delete = "DELETE FROM clientes WHERE CPF = ?";
		
		int check = 0;
		
		try 
		{
			stmt = connection.prepareStatement(delete);
			stmt.setString(1,CPF);
			check = stmt.executeUpdate();
			
			if(check > 0)
				System.out.println("DELETE CONCLUIDO");
			
			stmt.close();
			
		} 
		catch (SQLException err) 
		{
			throw new RuntimeException("ERRO AO DELETAR");
		}
		
	}

	@Override
	public void update(Clientes cliente) 
	{
		PreparedStatement stmt = null;
		
		String update = "UPDATE clientes SET firstName = ?, lastName = ?" + " WHERE CPF = ?";
		
		try 
		{
			int check;
			
			stmt = connection.prepareStatement(update);
			stmt.setString(1,cliente.getFirstNome());
			stmt.setString(2,cliente.getLastNome());
			stmt.setString(3,cliente.getCPF());
			check = stmt.executeUpdate();
			
			if(check > 0)
				System.out.println("UPDATE CONCLUIDO");
			
			stmt.close();
			
		} 
		
		catch (SQLException err) 
		{
			throw new RuntimeException("ERRO AO ATUALIZAR");
		}
		
	}
	
	public void updateCard(Clientes cliente)
	{
		PreparedStatement stmt = null;
		
		String update = "UPDATE clientes SET card = ?" + " WHERE CPF = ?";
		
		try 
		{
			int check;
			
			stmt = connection.prepareStatement(update);
			stmt.setBoolean(1,cliente.getCard());
			stmt.setString(2,cliente.getCPF());
			check = stmt.executeUpdate();
			
			if(check > 0)
				System.out.println("UPDATE CONCLUIDO");
			
			stmt.close();
			
		} 
		
		catch (SQLException err) 
		{
			throw new RuntimeException("ERRO AO ATUALIZAR");
		}
		
		
	}

	@Override
	public Clientes find(String cpf) 
	{
		String select = "SELECT * FROM clientes WHERE CPF = ?";
		
		PreparedStatement stmt = null;
		ResultSet rs;
		
		try 
		{
			stmt = connection.prepareStatement(select);
			stmt.setString(1,cpf);
			
			rs = stmt.executeQuery();
			
			if (rs.next())
			{
				Clientes cli = new Clientes();
				
				cli.setCPF(rs.getString("CPF"));
				cli.setFirstNome(rs.getNString("firstName"));
				cli.setLastNome(rs.getNString("lastName"));
				cli.setCard(rs.getBoolean("card"));
				
				stmt.close();
				//connection.close();
				
				return cli;
			}
			
			return null;
			
		} 
		
		catch (SQLException err) 
		{
			
			throw new RuntimeException("ERRO AO PESQUISAR");
		}
		
	}

	@Override
	public Clientes findEmail(String email)
	{
		String select = "SELECT * FROM clientes C WHERE CPF = (SELECT C.CPF_cliente FROM contas C WHERE c.EMAIL = ?);";
		
		PreparedStatement stmt = null;
		ResultSet rs;
		
		try 
		{
			stmt = connection.prepareStatement(select);
			stmt.setString(1,email);
			
			rs = stmt.executeQuery();
			
			if (rs.next())
			{
				Clientes cli = new Clientes();
				
				cli.setCPF(rs.getString("CPF"));
				cli.setFirstNome(rs.getNString("firstName"));
				cli.setLastNome(rs.getNString("lastName"));
				cli.setCard(rs.getBoolean("card"));
				
				stmt.close();
				//connection.close();
				
				return cli;
			}
			
			return null;
			
		} 
		
		catch (SQLException err) 
		{
			
			throw new RuntimeException("ERRO AO PESQUISAR");
		}
		
		
	}
	
}
