package Implements;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Entities.Pizzas;
import Model.PizzaDAO;

public class PizzasImp implements PizzaDAO
{
	
	private Connection connection;
	
	
	public PizzasImp(Connection connection)
	{
		this.connection = connection;
	}

        
	@Override
	public List<Pizzas> findAll() 
	{
		List<Pizzas> pizz = new ArrayList<Pizzas>();
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		String select = "SELECT * FROM pizzas";
		
		try
		{
			stmt = connection.prepareStatement(select);
			rs = stmt.executeQuery();
			
			while (rs.next())
			{
				Pizzas pizza = new Pizzas();
				
				pizza.setCOD_Prod(rs.getInt("COD_Prod"));
				pizza.setSabor(rs.getNString("sabor"));
				pizza.setDesc(rs.getNString("descricao"));
				pizza.setPreco(rs.getDouble("preco"));
				pizza.setTam(rs.getNString("tamanho"));
				
				pizz.add(pizza);
			}
			
			stmt.close();
			
		} 
		
		catch (SQLException err) 
		{
			throw new RuntimeException("ERRO NA PESQUISA");
		}
		
		return pizz;
	}

	@Override
	public Pizzas find(int Cod) 
	{
		String select = "SELECT * FROM pizzas WHERE COD_Prod = ?";
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try 
		{
			stmt = connection.prepareStatement(select);
			stmt.setInt(1,Cod);
			
			rs = stmt.executeQuery();
			
			if(rs.next())
			{
				Pizzas pizz = new Pizzas();
				
				pizz.setCOD_Prod(rs.getInt("COD_Prod"));
				pizz.setDesc(rs.getNString("descricao"));
				pizz.setPreco(rs.getDouble("preco"));
				pizz.setSabor(rs.getNString("sabor"));
				pizz.setTam(rs.getNString("tamanho"));
				
				stmt.close();
				
				return pizz;
				
			}
			
			return null;
		}
		
		catch (SQLException err) 
		{
			throw new RuntimeException("ERRO AO PESQUISAR");
		}
		
		
	}

}
