package Model;

import Entities.Telefones;

public interface TelefoneDAO 
{
	void insert(Telefones tel);
	//void delete(String CPF);
	void update(Telefones tel);
	Telefones find(String CPF);
	
}
