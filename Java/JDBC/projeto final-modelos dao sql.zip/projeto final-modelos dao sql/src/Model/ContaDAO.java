package Model;

import Entities.Contas;

public interface ContaDAO 
{
	void insert(Contas conta);
	void update(Contas conta);
	Contas find(String CPF);
	Contas findEmail(String EMAIL);
	
}
