package Model;

import Entities.Enderecos;

public interface EnderecoDAO
{
	void insert(Enderecos end);
	//void delete(String CPF);
	void update(Enderecos end);
	Enderecos find(String CPF);
	
}
