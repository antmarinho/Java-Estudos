package Model;

import Entities.Clientes;

public interface ClienteDAO 
{
	void insert(Clientes cliente);
	void update(Clientes cliente);
	void updateCard(Clientes cliente);
	Clientes find(String cpf);
	Clientes findEmail(String email);
	void delete(String CPF);
	
}
