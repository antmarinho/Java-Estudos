package Model;

import java.util.List;

import Entities.Pizzas;

public interface PizzaDAO
{
	Pizzas find(int Cod);
	List<Pizzas> findAll();
}
