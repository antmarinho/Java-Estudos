package Model;

import Entities.Pagamentos;

public interface PagamentoDAO 
{
	boolean insert(Pagamentos pag);
	void update(Pagamentos pag);
	Pagamentos find(String CPF);
	void delete(String CPF);
	
}
