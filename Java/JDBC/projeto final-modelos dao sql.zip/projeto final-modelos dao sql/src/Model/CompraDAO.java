package Model;

import java.util.List;
import Entities.Compras;


public interface CompraDAO 
{
	void inset(List<Compras> pizz);
	List<Compras> findAll(); 
}
