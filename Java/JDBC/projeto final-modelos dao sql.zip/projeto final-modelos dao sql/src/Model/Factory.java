package Model;

import DataBase.DBConnection;
import Implements.*;


public class Factory
{
	public static ClienteDAO createCliente()
	{
		return new ClientesImp(DBConnection.getConnection());
	}
	
	public static ContaDAO createConta()
	{
		return new ContasImp(DBConnection.getConnection());
	}
	
	public static TelefoneDAO createTelefone()
	{
		return new TelefonesImp(DBConnection.getConnection());
	}
	
	public static EnderecoDAO createEndereco()
	{
		return new EnderecosImp(DBConnection.getConnection());
	}
	
	public static PagamentoDAO createPagamento()
	{
		return new PagamentosImp(DBConnection.getConnection());
	}
	
        public static PizzaDAO createPizza()
	{
		return new PizzasImp(DBConnection.getConnection());
	}
        
        public static CompraDAO createCompra()
	{
		return new ComprasImp(DBConnection.getConnection());
	}
        
}
