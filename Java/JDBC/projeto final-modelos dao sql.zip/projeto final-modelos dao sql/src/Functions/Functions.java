package Functions;

public class Functions 
{
	public static int[] convertString(String cpf)
	{
		int v[] = new int[11];
		char str[];
		
		str = cpf.toCharArray();
		
		for(int i = 0; i < str.length; i++)
		{
			v[i] = Character.getNumericValue(str[i]);
			
		}
		
		return v;
	}
	
	public static int soma(int v[], int op)
	{
		int soma = 0;
		
		switch(op)
		{
			
			case 1:
				
				for(int i = 0; i < v.length; i++)
				{
					soma = soma + v[i];
				}
				
			break;
			
			case 2: 
				
				for(int i = 0; i < (v.length -2); i++)
				{
					soma = soma + (v[i] * ((v.length) - (i+1)));
					
				}
				
			break;
			
			case 3: 
				
				for(int i = 0; i < (v.length -1); i++)
				{
					soma = soma + (v[i] * ((v.length) - i));
					
				}
				
			break;
			
		}
		
		return soma;
	}
	
	public static boolean verifCPF(int v[])
	{
		
		int soma = soma(v,1);
		int verif = (soma/11);
		
		
		if(verif == v[1])
		{
			return false;
		}
		
		else
		{
			soma = soma(v,2);
			verif = (soma%11);
			
			int dig1 = (11-verif);
			
			if(dig1 >= 10)
				dig1 = 0;
			
			if(v[9] != dig1)
				return false;
			
			else
			{
				soma = soma(v,3);
				verif = (soma%11);
				
				int dig2 = (11-verif);
				
				if(dig2 >= 10)
					dig2 = 0;
				
				if(v[10] != dig2)
					return false;
				
				else
					return true;
				
			}
				
		}
		
	}
	
	public static String formataCPF(String cpf) 
	{
		String part1,part2,part3,part4;
		
		part1 = cpf.substring(0,3);
		part2 = cpf.substring(3, 6);
		part3 = cpf.substring(6, 9);
		part4 = cpf.substring(9, 11);
		
		return part1 + "." + part2 + "." + part3 + "-" + part4;
	}
	
	public static String formataCEP(String cep) 
	{
		String part1,part2;
		
		part1 = cep.substring(0,5);
		part2 = cep.substring(5,8);
		
		
		return part1 + "-" + part2;
	}

	public static String formataTel(String ddd, String tel) 
	{
		String part1,part2;
		
		part1 = tel.substring(0, 5);
		part2 = tel.substring(5, 9);
		
		
		return "(" + ddd + ")" + " " + part1 + "-" + part2;

	}
	
	public static String formataCartao(String numero) 
	{
		String part1,part2,part3,part4;
		
		part1 = numero.substring(0, 4);
		part2 = numero.substring(4, 8);
		part3 = numero.substring(8, 12);
		part4 = numero.substring(12, 16);
		
		
		return part1 + "-" + part2 + "-" + part3 + "-" + part4;
	}
	
	public static String formataData(String dia, String mes, String ano)
	{
		
		return ano + "-" + mes + "-" + dia;
	}
	
	public static String formataDataBrasil(String data)
	{
		String dia,mes,ano;
	
		dia = data.substring(8, 10);
		mes = data.substring(5, 7);
		ano = data.substring(0, 4);
		
		return dia + "/" + mes + "/" + ano;
	}

}
