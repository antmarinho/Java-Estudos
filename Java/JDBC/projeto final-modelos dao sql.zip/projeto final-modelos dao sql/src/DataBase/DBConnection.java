package DataBase;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection
{
	static Connection connection = null;
	
	private static Properties loadProperties()
	{
		Properties props = new Properties();
		
		try 
		{
			FileInputStream fs = new FileInputStream("db.properties");
			
			props.load(fs);
			
		} 
		
		catch (IOException err) 
		{
			err.printStackTrace();//throw new RuntimeException("ARQUIVO NAO ENCONTRADO");
		}
		
		return props;
	}
	
	public static Connection getConnection()
	{
		if(connection == null)
		{
			Properties props = loadProperties();
			
			String url = props.getProperty("url");
			
			try 
			{
				connection = DriverManager.getConnection(url, props);
			} 
			catch (SQLException err)
			{
				throw new RuntimeException("CONEXAO FALHOU");
			}
			
		}
		
		return connection;
	}
	
	public static void closeConnection()
	{
		try 
		{
			connection.close();
		} 
		
		catch (SQLException err) 
		{
			throw new RuntimeException("FALHA AO FECHAR CONEXAO");
		}
		
	}

}
